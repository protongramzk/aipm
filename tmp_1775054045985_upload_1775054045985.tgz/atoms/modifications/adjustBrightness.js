export function adjustBrightness(rgba, amount) {
  if (!rgba || typeof rgba.r === 'undefined' || typeof rgba.g === 'undefined' || typeof rgba.b === 'undefined') {
    return null;
  }

  let r = rgba.r;
  let g = rgba.g;
  let b = rgba.b;
  let a = typeof rgba.a === 'number' ? rgba.a : 1;

  // Amount is typically -100 to 100
  const factor = 1 + (amount / 100);

  r = Math.round(Math.max(0, Math.min(255, r * factor)));
  g = Math.round(Math.max(0, Math.min(255, g * factor)));
  b = Math.round(Math.max(0, Math.min(255, b * factor)));

  return { r, g, b, a };
}
