export function mixColors(rgba1, rgba2, ratio) {
  if (!rgba1 || !rgba2 || typeof ratio !== 'number') {
    return null;
  }

  ratio = Math.max(0, Math.min(1, ratio)); // Clamp ratio between 0 and 1

  const r = Math.round(rgba1.r * (1 - ratio) + rgba2.r * ratio);
  const g = Math.round(rgba1.g * (1 - ratio) + rgba2.g * ratio);
  const b = Math.round(rgba1.b * (1 - ratio) + rgba2.b * ratio);
  const a = rgba1.a * (1 - ratio) + rgba2.a * ratio;

  return { r, g, b, a };
}
