import { hexToRgba } from '../conversions/hexToRgba.js';

export function parseColorString(colorString) {
  if (!colorString || typeof colorString !== 'string') return null;

  colorString = colorString.trim().toLowerCase();

  // HEX
  if (colorString.startsWith('#')) {
    return hexToRgba(colorString);
  }

  // RGBA/RGB
  const rgbaMatch = colorString.match(/^rgba?\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})(?:,\s*([0-1]?\.?\d*))?\)$/);
  if (rgbaMatch) {
    let r = parseInt(rgbaMatch[1], 10);
    let g = parseInt(rgbaMatch[2], 10);
    let b = parseInt(rgbaMatch[3], 10);
    let a = typeof rgbaMatch[4] !== 'undefined' ? parseFloat(rgbaMatch[4]) : 1;

    // Clamp values
    r = Math.max(0, Math.min(255, r));
    g = Math.max(0, Math.min(255, g));
    b = Math.max(0, Math.min(255, b));
    a = Math.max(0, Math.min(1, a));

    return { r, g, b, a };
  }

  // HSLA/HSL (Note: This function only parses to RGBA, so HSL parsing should ideally go via hslToRgba)
  // For simplicity and direct parsing, let's treat HSL as needing a separate conversion atom.
  // This parser will primarily focus on direct RGBA/HEX parsing. HSL string input should be converted
  // via a dedicated HSL parsing atom if full HSL string support is needed here without an HSL internal type.
  // For now, let's assume direct RGBA or HEX is sufficient for 'parsing a color string'.

  // For full HSL string support, one might add a dependency to hslToRgba here
  // and parse the HSL string into {h,s,l,a} first, then convert.
  // Example (if hslToRgba were imported):
  const hslaMatch = colorString.match(/^hsla?\((\d{1,3}),\s*(\d{1,3})%,\s*(\d{1,3})%(?:,\s*([0-1]?\.?\d*))?\)$/);
  if (hslaMatch) {
    let h = parseInt(hslaMatch[1], 10);
    let s = parseInt(hslaMatch[2], 10) / 100;
    let l = parseInt(hslaMatch[3], 10) / 100;
    let a = typeof hslaMatch[4] !== 'undefined' ? parseFloat(hslaMatch[4]) : 1;

    // Clamp values
    h = Math.max(0, Math.min(360, h));
    s = Math.max(0, Math.min(1, s));
    l = Math.max(0, Math.min(1, l));
    a = Math.max(0, Math.min(1, a));

    // This parser returns RGBA, so we need hslToRgba here
    // import { hslToRgba } from '../conversions/hslToRgba.js';
    // return hslToRgba({h, s, l, a});
    // For this example, I'll assume only hex/rgba string parsing to keep dependencies simple.
    // If full HSL string parsing to RGBA is needed here, hslToRgba would be a dependency.
    // Given the mol.md structure, parseColorString directly uses hexToRgba, so HSL conversion
    // is handled by the rgbaToHsl/hslToRgba atoms directly, not through this general parser.
    // To simplify and align with current mol.md, let's omit direct HSL string parsing to RGBA here.
    return null; // For now, treat HSL strings as unsupported by this specific parser to RGBA.
  }

  return null;
}
