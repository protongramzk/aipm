export function rgbaToHsl(rgba) {
  if (!rgba || typeof rgba.r === 'undefined' || typeof rgba.g === 'undefined' || typeof rgba.b === 'undefined') {
    return null;
  }

  let r = rgba.r / 255;
  let g = rgba.g / 255;
  let b = rgba.b / 255;
  let a = typeof rgba.a === 'number' ? rgba.a : 1;

  let max = Math.max(r, g, b);
  let min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) {
    h = s = 0; // achromatic
  } else {
    let d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }

  return { h: h * 360, s, l, a };
}
