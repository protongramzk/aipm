export function hexToRgba(hex) {
  if (!hex || typeof hex !== 'string') return null;

  let r = 0, g = 0, b = 0, a = 1;

  // Expand shorthand form (e.g. "#03F") to full form (e.g. "#0033FF")
  const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])([a-f\d])?$/i;
  hex = hex.replace(shorthandRegex, function(m, r, g, b, a) {
    return r + r + g + g + b + b + (a ? a + a : '');
  });

  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})?$/i.exec(hex);

  if (result) {
    r = parseInt(result[1], 16);
    g = parseInt(result[2], 16);
    b = parseInt(result[3], 16);
    a = result[4] ? (parseInt(result[4], 16) / 255) : 1;
    return { r, g, b, a };
  }

  return null;
}
