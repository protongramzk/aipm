export function rgbaToHex(rgba) {
  if (!rgba || typeof rgba.r === 'undefined' || typeof rgba.g === 'undefined' || typeof rgba.b === 'undefined') {
    return null;
  }

  let r = Math.round(Math.max(0, Math.min(255, rgba.r)));
  let g = Math.round(Math.max(0, Math.min(255, rgba.g)));
  let b = Math.round(Math.max(0, Math.min(255, rgba.b)));
  let a = typeof rgba.a === 'number' ? Math.max(0, Math.min(1, rgba.a)) : 1;

  const toHex = (c) => {
    const hex = Math.round(c).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  };

  let hex = `#${toHex(r)}${toHex(g)}${toHex(b)}`;

  if (a !== 1) {
    hex += toHex(a * 255);
  }

  return hex.toUpperCase();
}
