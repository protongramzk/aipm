import { calculateLuminance } from './calculateLuminance.js';

export function calculateContrastRatio(rgba1, rgba2) {
  if (!rgba1 || !rgba2) return 0;

  const L1 = calculateLuminance(rgba1);
  const L2 = calculateLuminance(rgba2);

  // The formula is (L1 + 0.05) / (L2 + 0.05), where L1 is the lighter of the two colors.
  // WCAG requires a ratio of at least 4.5:1 for normal text and 3:1 for large text.
  const contrast = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);

  return contrast;
}
