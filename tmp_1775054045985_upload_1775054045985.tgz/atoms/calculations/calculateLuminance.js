export function calculateLuminance(rgba) {
  if (!rgba || typeof rgba.r === 'undefined' || typeof rgba.g === 'undefined' || typeof rgba.b === 'undefined') {
    return 0;
  }

  let r = rgba.r / 255;
  let g = rgba.g / 255;
  let b = rgba.b / 255;

  // Apply a linear transformation if values are in gamma space
  const toLinear = (c) => {
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  };

  r = toLinear(r);
  g = toLinear(g);
  b = toLinear(b);

  // Calculate luminance (WCAG 2.0/2.1 formula)
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
