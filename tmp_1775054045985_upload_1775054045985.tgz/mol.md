1. Overview
Ini adalah library utilitas warna yang dirancang untuk membantu dalam konversi, perhitungan kontras WCAG, penyesuaian kecerahan, dan pencampuran warna dalam berbagai format seperti RGBA, HEX, dan HSL. Dibuat dengan filosofi "pemrograman kimiawi" di mana setiap fungsi adalah "atom" yang fokus pada satu tugas spesifik dan dapat digabungkan menjadi "molekul" yang lebih kompleks.

2. Atoms

### hexToRgba
- Input:
  - hex: string (e.g., "#FF0000", "#F00", "#FF0000AA")
- Output:
  - object | null ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) } or null if invalid)
- Depends on: None

### rgbaToHex
- Input:
  - rgba: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
- Output:
  - string (e.g., "#FF0000", "#FF0000AA")
- Depends on: None

### rgbaToHsl
- Input:
  - rgba: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
- Output:
  - object ({ h: number (0-360), s: number (0-1), l: number (0-1), a: number (0-1) })
- Depends on: None

### hslToRgba
- Input:
  - hsl: object ({ h: number (0-360), s: number (0-1), l: number (0-1), a: number (0-1) })
- Output:
  - object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
- Depends on: None

### parseColorString
- Input:
  - colorString: string (e.g., "#FF0000", "rgb(255,0,0)", "hsl(0,100%,50%)")
- Output:
  - object | null ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) } or null if invalid)
- Depends on: hexToRgba

### calculateLuminance
- Input:
  - rgba: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
- Output:
  - number (0-1)
- Depends on: None

### calculateContrastRatio
- Input:
  - rgba1: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
  - rgba2: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
- Output:
  - number (ratio)
- Depends on: calculateLuminance

### adjustBrightness
- Input:
  - rgba: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
  - amount: number (-100 to 100, where 0 is no change, 100 is max bright, -100 is min bright)
- Output:
  - object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
- Depends on: None

### mixColors
- Input:
  - rgba1: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
  - rgba2: object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
  - ratio: number (0-1, where 0 is 100% rgba1, 1 is 100% rgba2)
- Output:
  - object ({ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) })
- Depends on: None

3. Dependency Graph
parseColorString -> hexToRgba
calculateContrastRatio -> calculateLuminance

4. Usage Flow
```javascript
import { parseColorString } from './atoms/parsing/parseColorString.js';
import { calculateContrastRatio } from './atoms/calculations/calculateContrastRatio.js';
import { adjustBrightness } from './atoms/modifications/adjustBrightness.js';
import { rgbaToHex } from './atoms/conversions/rgbaToHex.js';

// 1. Parse colors from different formats
const color1Rgba = parseColorString('#FF5733'); // A shade of orange
const color2Rgba = parseColorString('rgb(0,0,0)'); // Black

if (color1Rgba && color2Rgba) {
  // 2. Calculate WCAG contrast ratio
  const contrast = calculateContrastRatio(color1Rgba, color2Rgba);
  console.log(`Contrast between #FF5733 and black: ${contrast.toFixed(2)}:1`);

  // 3. Adjust brightness
  const brighterColor = adjustBrightness(color1Rgba, 20); // Make 20% brighter
  console.log(`Brighter #FF5733 (RGBA): `, brighterColor);

  // 4. Convert back to HEX
  const brighterHex = rgbaToHex(brighterColor);
  console.log(`Brighter #FF5733 (HEX): ${brighterHex}`);
}
```

5. Constraints
- Internal RGBA representation: `{ r: number (0-255), g: number (0-255), b: number (0-255), a: number (0-1) }`.
- Semua input `a` (alpha) diharapkan dalam rentang `0-1` untuk objek RGBA/HSL internal. Input string untuk HEX atau RGBA/HSLA dapat memiliki alpha dalam rentang `0-1` atau `0-255` (untuk RGBA/HSLA string).
- Fungsi tidak melakukan validasi input yang ketat melebihi format dasar. Pastikan input numerik berada dalam rentang yang diharapkan (e.g., 0-255 untuk R,G,B; 0-1 untuk alpha).
- OKLCH atau format warna lain saat ini tidak didukung dan dapat ditambahkan sebagai "atom" baru di masa mendatang.